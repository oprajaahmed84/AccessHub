শুধু Android ফোন দিয়ে GitHub Actions-এ APK build করার নিয়ম

১) ZIP extract করুন। ভিতরে AccessHub_Android_Studio_Project.zip এবং .github folder থাকবে।
২) github.com এ account খুলে New repository তৈরি করুন (Public বা Private)।
৩) এই দুইটি item repository-তে upload করুন: AccessHub_Android_Studio_Project.zip এবং .github/workflows/build.yml
   .github/workflows ফোল্ডার তৈরি করে build.yml সেখানে রাখতে হবে।
৪) Repository > Actions > Build Android APK > Run workflow চাপুন।
৫) Build শেষ হলে workflow run খুলে Artifacts থেকে AccessHub-demo-apk ডাউনলোড করুন।
৬) ZIP extract করে app-debug.apk ইনস্টল করুন। Android-এ "Install unknown apps" permission চাইতে পারে।

এটি নিজের offline demo app। ১০০০টি demo key APK assets-এ আছে, তাই এগুলো নিরাপদ paid key নয়।
আসল ANGRY MOD-এর official key/server বা game modification এতে নেই।
